package com.example.expiryapp

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Base64
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var ocrCameraUri: Uri? = null
    private val FILE_PICK = 1001
    private val OCR_PICK = 1002
    private val CAMERA_PERMISSION = 1003

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("expiry_reminders_v7", "保质期提醒", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        web = WebView(this)
        web.layoutParams = ViewGroup.LayoutParams(-1, -1)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                return try {
                    startActivityForResult(p?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                    }, FILE_PICK)
                    true
                } catch (e: Exception) { chooser = null; false }
            }
        }

        web.addJavascriptInterface(object {
            @JavascriptInterface fun scanBarcode() {
                runOnUiThread {
                    GmsBarcodeScanning.getClient(this@MainActivity).startScan()
                        .addOnSuccessListener { barcode ->
                            val raw = barcode.rawValue ?: ""
                            web.evaluateJavascript("setScannedBarcode(${org.json.JSONObject.quote(raw)})", null)
                        }
                        .addOnFailureListener { Toast.makeText(this@MainActivity, "扫码失败或已取消", Toast.LENGTH_SHORT).show() }
                }
            }

            @JavascriptInterface fun recognizeProduct() {
                runOnUiThread { openOcrChooser() }
            }
        }, "Android")

        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    private fun openOcrChooser() {
        val gallery = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION)
            else launchOcrChooser(gallery, null)
            return
        }
        launchOcrChooser(gallery, createCameraIntent())
    }

    private fun launchOcrChooser(gallery: Intent, camera: Intent?) {
        val chooserIntent = Intent.createChooser(gallery, "选择商品照片")
        if (camera != null) chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
        try { startActivityForResult(chooserIntent, OCR_PICK) }
        catch (e: Exception) { Toast.makeText(this, "无法打开图片选择器", Toast.LENGTH_SHORT).show() }
    }

    private fun createCameraIntent(): Intent? {
        return try {
            val file = File.createTempFile("ocr_", ".jpg", cacheDir)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            ocrCameraUri = uri
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (e: Exception) { null }
    }

    private fun recognizeFromUri(uri: Uri) {
        Toast.makeText(this, "正在识别包装文字…", Toast.LENGTH_SHORT).show()
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val text = result.text ?: ""
                    val data = parseProductText(text)
                    data["photo"] = compressUriToDataUrl(uri) ?: ""
                    val json = org.json.JSONObject(data as Map<*, *>).toString()
                    web.evaluateJavascript("setRecognizedProduct(${org.json.JSONObject.quote(json)})", null)
                    Toast.makeText(this, if (text.isBlank()) "没有识别到文字，请换一张清晰照片" else "识别完成，请确认后保存", Toast.LENGTH_SHORT).show()
                    recognizer.close()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "识别失败，请拍清晰、正面的包装照片", Toast.LENGTH_SHORT).show()
                    recognizer.close()
                }
        } catch (e: Exception) {
            Toast.makeText(this, "无法读取照片", Toast.LENGTH_SHORT).show()
        }
    }

    private fun parseProductText(raw: String): MutableMap<String, String> {
        val text = raw.replace("\r", "\n").replace("\u00A0", " ")
        val lines = text.split("\n").map { it.trim().replace("  +".toRegex(), " ") }.filter { it.isNotBlank() }
        val out = mutableMapOf<String, String>("name" to "", "spec" to "", "production" to "", "expiry" to "", "shelfMonths" to "", "qty" to "1", "barcode" to "")

        fun normalizeDate(y: Int, m: Int, d: Int): String? = try {
            val cal = java.util.Calendar.getInstance(); cal.clear(); cal.set(y, m - 1, d)
            if (cal.get(java.util.Calendar.YEAR) != y || cal.get(java.util.Calendar.MONTH) != m - 1 || cal.get(java.util.Calendar.DAY_OF_MONTH) != d) null
            else "%04d-%02d-%02d".format(y, m, d)
        } catch (_: Exception) { null }

        val dateRegex = Regex("(20\\d{2})[./年-](\\d{1,2})[./月-](\\d{1,2})")
        fun dates(s: String): List<String> = dateRegex.findAll(s).mapNotNull { m -> normalizeDate(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()) }.toList()

        for (line in lines) {
            val ds = dates(line)
            if (ds.isNotEmpty()) {
                when {
                    Regex("生产|制造|出厂").containsMatchIn(line) -> out["production"] = ds.first()
                    Regex("有效期至|到期|失效|截止").containsMatchIn(line) -> out["expiry"] = ds.first()
                    out["production"].isBlank() -> out["production"] = ds.first()
                    out["expiry"].isBlank() -> out["expiry"] = ds.first()
                }
            }
            Regex("保质期\\s*[:：]?\\s*(\\d+)\\s*(个月|月|年)").find(line)?.let {
                val n = it.groupValues[1].toInt()
                out["shelfMonths"] = if (it.groupValues[2] == "年") (n * 12).toString() else n.toString()
            }
            Regex("(?:规格|净含量|含量|容量|重量)\\s*[:：]?\\s*([0-9]+(?:\\.[0-9]+)?\\s*(?:kg|g|ml|mL|L|斤|克|毫升|升|片|粒|支|袋|盒|罐|包))", RegexOption.IGNORE_CASE).find(line)?.let { out["spec"] = it.groupValues[1].trim() }
            Regex("数量\\s*[:：]?\\s*(\\d+)").find(line)?.let { out["qty"] = it.groupValues[1] }
        }

        if (out["name"].isNullOrBlank()) {
            val bad = Regex("生产|制造|出厂|保质期|有效期|净含量|规格|数量|条码|二维码|电话|地址|配料|营养")
            val candidate = lines.firstOrNull { it.length in 2..30 && !bad.containsMatchIn(it) && !dateRegex.containsMatchIn(it) && !it.matches(Regex("[0-9A-Za-z./:_-]+")) }
            out["name"] = candidate ?: ""
        }
        if (out["spec"].isNullOrBlank()) {
            val candidate = lines.firstOrNull { Regex("\\d+(?:\\.\\d+)?\\s*(?:kg|g|ml|mL|L|克|毫升|升|片|粒|支|袋|盒|罐|包)", RegexOption.IGNORE_CASE).containsMatchIn(it) }
            if (candidate != null) out["spec"] = Regex("\\d+(?:\\.\\d+)?\\s*(?:kg|g|ml|mL|L|克|毫升|升|片|粒|支|袋|盒|罐|包)", RegexOption.IGNORE_CASE).find(candidate)?.value ?: ""
        }
        if (out["barcode"].isNullOrBlank()) {
            val code = Regex("(?<!\\d)\\d{8,14}(?!\\d)").find(text)?.value
            if (code != null) out["barcode"] = code
        }
        return out
    }

    private fun compressUriToDataUrl(uri: Uri): String? {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            val bitmap = BitmapFactory.decodeStream(input); input.close()
            bitmap ?: return null
            val max = 1280.0
            val scale = minOf(1.0, max / maxOf(bitmap.width, bitmap.height).toDouble())
            val w = (bitmap.width * scale).toInt().coerceAtLeast(1)
            val h = (bitmap.height * scale).toInt().coerceAtLeast(1)
            val resized = Bitmap.createScaledBitmap(bitmap, w, h, true)
            val out = ByteArrayOutputStream(); resized.compress(Bitmap.CompressFormat.JPEG, 82, out)
            if (resized !== bitmap) resized.recycle()
            bitmap.recycle()
            "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) { null }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION) {
            val gallery = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            launchOcrChooser(gallery, if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) createCameraIntent() else null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_PICK) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); chooser = null
        } else if (requestCode == OCR_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: ocrCameraUri
            if (uri != null) recognizeFromUri(uri)
        }
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
