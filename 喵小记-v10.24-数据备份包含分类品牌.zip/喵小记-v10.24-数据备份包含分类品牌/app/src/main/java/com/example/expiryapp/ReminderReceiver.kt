package com.example.expiryapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_REMINDER = "com.example.expiryapp.ACTION_REMINDER"
        const val PREFS = "expiry_reminders"
        const val DATA = "data"
        const val CHANNEL = "expiry_reminders_v10"
        const val REQ = 7015

        fun schedule(context: Context, data: String) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(DATA, data).apply()
            val am = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val intent = Intent(context, ReminderReceiver::class.java).setAction(ACTION_REMINDER)
            val pi = PendingIntent.getBroadcast(context, REQ, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.cancel(pi)
            val settings = runCatching { JSONObject(data).optJSONObject("settings") }.getOrNull()
            if (settings?.optBoolean("enabled", true) != true) return
            val time = settings.optString("time", "09:00")
            val parts = time.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: 9
            val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, minute.coerceIn(0, 59))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            am.setInexactRepeating(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, android.app.AlarmManager.INTERVAL_DAY, pi)
        }
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val data = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(DATA, null)
            if (!data.isNullOrBlank()) schedule(context, data)
            return
        }
        if (intent?.action != ACTION_REMINDER) return
        val data = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(DATA, null) ?: return
        notifyForData(context, data)
    }

    private fun notifyForData(context: Context, data: String) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val root = runCatching { JSONObject(data) }.getOrNull() ?: return
        val s = root.optJSONObject("settings") ?: return
        if (!s.optBoolean("enabled", true)) return
        val arr = root.optJSONArray("items") ?: JSONArray()
        val now = Calendar.getInstance()
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }
        val lines = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val x = arr.optJSONObject(i) ?: continue
            if (x.optBoolean("handled", false)) continue
            val expiry = x.optString("expiry", "")
            if (expiry.isBlank()) continue
            val d = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(expiry) }.getOrNull() ?: continue
            val exp = Calendar.getInstance().apply { time = d; set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }
            val days = ceil((exp.timeInMillis - today.timeInMillis) / 86400000.0).toInt()
            val name = x.optString("name", "未命名")
            val matched = when {
                days == 60 && s.optBoolean("before60", true) -> "还有 60 天到期"
                days == 30 && s.optBoolean("before30", true) -> "还有 30 天到期"
                days == 7 && s.optBoolean("before7", true) -> "还有 7 天到期"
                else -> null
            }
            if (matched != null) lines.add("$name：$matched")
        }
        if (lines.isEmpty()) return
        createChannel(context)
        val title = "喵小记提醒"
        val body = if (lines.size == 1) lines[0] else "有 ${lines.size} 件商品需要关注"
        val detail = lines.take(8).joinToString("\n") + if (lines.size > 8) "\n还有 ${lines.size - 8} 件" else ""
        val open = PendingIntent.getActivity(context, 7020, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(7021, n)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "保质期提醒", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
}
