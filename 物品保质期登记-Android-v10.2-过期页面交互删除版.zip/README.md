# 质宝期 Android v8.8 大容量本地数据库版

本版在 v8.7 基础上升级本地数据存储：
- 物品记录改用 Android WebView IndexedDB 保存，不再把整批物品 JSON 持续塞入 localStorage。
- 照片随物品记录保存在 IndexedDB 中，适合比 localStorage 更大的本地数据量。
- 首次启动会自动把旧版 localStorage 中的 `expiry_items_v1` 数据迁移到 IndexedDB。
- 分类和已保存筛选条件仍使用 localStorage，因为它们数据量很小。
- 继续保持无 INTERNET 网络权限。
- 保留拍照 OCR、扫码、品牌、首页新增/编辑、过期处理、筛选、备份恢复、CSV 等功能。

说明：IndexedDB 的可用容量仍由 Android/WebView 的设备存储和浏览器配额决定，并非无限容量。照片越多，占用空间越大；建议定期导出 JSON 备份。


## v9.0 离线识别
- 拍照识别使用本地打包的 ML Kit 中文文字识别模型。
- 扫码使用本地打包的 ML Kit 条码/二维码识别库；先拍摄一张包含二维码或条码的照片，再自动识别。
- 应用 Manifest 不声明 INTERNET 权限，识别过程不需要应用联网。
- 如果系统第一次使用相机，需要允许相机权限。
