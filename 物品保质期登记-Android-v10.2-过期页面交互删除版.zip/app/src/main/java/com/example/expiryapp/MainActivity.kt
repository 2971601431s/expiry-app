package com.example.expiryapp

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Base64
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var ocrCameraUri: Uri? = null
    private val FILE_PICK = 1001
    private val OCR_PICK = 1002
    private val BARCODE_PICK = 1004
    private val CAMERA_PERMISSION = 1003
    private var barcodeCameraUri: Uri? = null
    private var pendingCameraAction: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("expiry_reminders_v7", "保质期提醒", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        web = WebView(this)
        web.layoutParams = ViewGroup.LayoutParams(-1, -1)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                return try {
                    startActivityForResult(p?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                    }, FILE_PICK)
                    true
                } catch (e: Exception) { chooser = null; false }
            }
        }

        web.addJavascriptInterface(object {
            @JavascriptInterface fun scanBarcode() {
                runOnUiThread { openBarcodeCamera() }
            }

            @JavascriptInterface fun recognizeProduct() {
                runOnUiThread { openOcrChooser() }
            }
        }, "Android")

        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    private fun openBarcodeCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 23) {
                pendingCameraAction = "barcode"
                requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION)
            }
            return
        }
        val intent = createBarcodeCameraIntent()
        if (intent == null) {
            Toast.makeText(this, "无法打开相机", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivityForResult(intent, BARCODE_PICK)
        } catch (_: Exception) {
            Toast.makeText(this, "无法打开相机", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createBarcodeCameraIntent(): Intent? {
        return try {
            val file = File.createTempFile("barcode_", ".jpg", cacheDir)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            barcodeCameraUri = uri
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (_: Exception) { null }
    }

    private fun recognizeBarcodeFromUri(uri: Uri) {
        Toast.makeText(this, "正在识别二维码 / 条码…", Toast.LENGTH_SHORT).show()
        try {
            val image = InputImage.fromFilePath(this, uri)
            val options = BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_QR_CODE, Barcode.FORMAT_AZTEC, Barcode.FORMAT_DATA_MATRIX,
                    Barcode.FORMAT_PDF417, Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
                    Barcode.FORMAT_CODE_93, Barcode.FORMAT_CODABAR, Barcode.FORMAT_EAN_13,
                    Barcode.FORMAT_EAN_8, Barcode.FORMAT_ITF, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E
                )
                .build()
            val scanner = BarcodeScanning.getClient(options)
            scanner.process(image)
                .addOnSuccessListener { codes ->
                    val value = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                    if (!value.isNullOrBlank()) {
                        web.evaluateJavascript("setScannedBarcode(${org.json.JSONObject.quote(value)})", null)
                        Toast.makeText(this, "识别成功：$value", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "没有识别到二维码或条码，请对准并拍清晰", Toast.LENGTH_SHORT).show()
                    }
                    scanner.close()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "二维码 / 条码识别失败，请重新拍摄", Toast.LENGTH_SHORT).show()
                    scanner.close()
                }
        } catch (_: Exception) {
            Toast.makeText(this, "无法读取扫码照片", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openOcrChooser() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 23) {
                pendingCameraAction = "ocr"
                requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION)
            }
            return
        }
        showOcrSourceChooser()
    }

    private fun showOcrSourceChooser() {
        AlertDialog.Builder(this)
            .setTitle("拍照识别")
            .setItems(arrayOf("📷 立即拍照识别", "🖼️ 从相册选择照片")) { _, which ->
                if (which == 0) {
                    val camera = createCameraIntent()
                    if (camera == null) {
                        Toast.makeText(this, "无法打开相机", Toast.LENGTH_SHORT).show()
                    } else {
                        try { startActivityForResult(camera, OCR_PICK) }
                        catch (_: Exception) { Toast.makeText(this, "无法打开相机", Toast.LENGTH_SHORT).show() }
                    }
                } else {
                    val gallery = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = "image/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    try { startActivityForResult(gallery, OCR_PICK) }
                    catch (_: Exception) { Toast.makeText(this, "无法打开相册", Toast.LENGTH_SHORT).show() }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun createCameraIntent(): Intent? {
        return try {
            val file = File.createTempFile("ocr_", ".jpg", cacheDir)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            ocrCameraUri = uri
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (e: Exception) { null }
    }

    private fun recognizeFromUri(uri: Uri) {
        Toast.makeText(this, "正在识别包装文字…", Toast.LENGTH_SHORT).show()
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    val text = result.text ?: ""
                    val data = parseProductText(text)
                    data["photo"] = compressUriToDataUrl(uri) ?: ""
                    val json = org.json.JSONObject(data as Map<*, *>).toString()
                    web.evaluateJavascript("setRecognizedProduct(${org.json.JSONObject.quote(json)})", null)
                    Toast.makeText(this, if (text.isBlank()) "没有识别到文字，请换一张清晰照片" else "识别完成，请确认后保存", Toast.LENGTH_SHORT).show()
                    recognizer.close()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "识别失败，请拍清晰、正面的包装照片", Toast.LENGTH_SHORT).show()
                    recognizer.close()
                }
        } catch (e: Exception) {
            Toast.makeText(this, "无法读取照片", Toast.LENGTH_SHORT).show()
        }
    }

    private fun parseProductText(raw: String): MutableMap<String, String> {
        val text = raw.replace("\r", "\n").replace("\u00A0", " ")
        val lines = text.split("\n").map { it.trim().replace("  +".toRegex(), " ") }.filter { it.isNotBlank() }
        val out = mutableMapOf<String, String>("name" to "", "brand" to "", "spec" to "", "production" to "", "expiry" to "", "shelfMonths" to "", "qty" to "1", "barcode" to "")

        fun normalizeDate(y: Int, m: Int, d: Int): String? = try {
            val cal = java.util.Calendar.getInstance(); cal.clear(); cal.set(y, m - 1, d)
            if (cal.get(java.util.Calendar.YEAR) != y || cal.get(java.util.Calendar.MONTH) != m - 1 || cal.get(java.util.Calendar.DAY_OF_MONTH) != d) null
            else "%04d-%02d-%02d".format(y, m, d)
        } catch (_: Exception) { null }

        val dateRegex = Regex("(20\\d{2})[./年-](\\d{1,2})[./月-](\\d{1,2})")
        fun dates(s: String): List<String> = dateRegex.findAll(s).mapNotNull { m -> normalizeDate(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()) }.toList()

        for (line in lines) {
            val ds = dates(line)
            if (ds.isNotEmpty()) {
                when {
                    Regex("生产|制造|出厂").containsMatchIn(line) -> out["production"] = ds.first()
                    Regex("有效期至|到期|失效|截止").containsMatchIn(line) -> out["expiry"] = ds.first()
                    out["production"].isNullOrBlank() -> out["production"] = ds.first()
                    out["expiry"].isNullOrBlank() -> out["expiry"] = ds.first()
                }
            }
            Regex("保质期\\s*[:：]?\\s*(\\d+)\\s*(个月|月|年)").find(line)?.let {
                val n = it.groupValues[1].toInt()
                out["shelfMonths"] = if (it.groupValues[2] == "年") (n * 12).toString() else n.toString()
            }
            Regex("(?:规格|净含量|含量|容量|重量)\\s*[:：]?\\s*([0-9]+(?:\\.[0-9]+)?\\s*(?:kg|g|ml|mL|L|斤|克|毫升|升|片|粒|支|袋|盒|罐|包))", RegexOption.IGNORE_CASE).find(line)?.let { out["spec"] = it.groupValues[1].trim() }
            Regex("数量\\s*[:：]?\\s*(\\d+)").find(line)?.let { out["qty"] = it.groupValues[1] }
        }

        if (out["brand"].isNullOrBlank()) {
            val brandPatterns = listOf(
                Regex("""(?:品牌|牌)\s*[:：]?\s*([\u4e00-\u9fa5A-Za-z0-9·&\-]{2,20})"""),
                Regex("""^([\u4e00-\u9fa5A-Za-z][\u4e00-\u9fa5A-Za-z0-9·&\-]{1,12})$""")
            )
            for (line in lines.take(8)) {
                val m = brandPatterns[0].find(line) ?: brandPatterns[1].find(line)
                val v = m?.groupValues?.getOrNull(1)?.trim()
                if (!v.isNullOrBlank() && !Regex("生产|制造|保质|有效期|净含量|规格|数量|配料|地址|电话").containsMatchIn(v)) {
                    out["brand"] = v
                    break
                }
            }
        }

        if (out["name"].isNullOrBlank()) {
            val bad = Regex("生产|制造|出厂|保质期|有效期|净含量|规格|数量|条码|二维码|电话|地址|配料|营养")
            val candidate = lines.firstOrNull { it.length in 2..30 && !bad.containsMatchIn(it) && !dateRegex.containsMatchIn(it) && !it.matches(Regex("[0-9A-Za-z./:_-]+")) }
            out["name"] = candidate ?: ""
        }
        if (out["spec"].isNullOrBlank()) {
            val candidate = lines.firstOrNull { Regex("\\d+(?:\\.\\d+)?\\s*(?:kg|g|ml|mL|L|克|毫升|升|片|粒|支|袋|盒|罐|包)", RegexOption.IGNORE_CASE).containsMatchIn(it) }
            if (candidate != null) out["spec"] = Regex("\\d+(?:\\.\\d+)?\\s*(?:kg|g|ml|mL|L|克|毫升|升|片|粒|支|袋|盒|罐|包)", RegexOption.IGNORE_CASE).find(candidate)?.value ?: ""
        }
        if (out["barcode"].isNullOrBlank()) {
            val code = Regex("(?<!\\d)\\d{8,14}(?!\\d)").find(text)?.value
            if (code != null) out["barcode"] = code
        }
        return out
    }

    private fun compressUriToDataUrl(uri: Uri): String? {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            val bitmap = BitmapFactory.decodeStream(input); input.close()
            bitmap ?: return null
            val max = 1280.0
            val scale = minOf(1.0, max / maxOf(bitmap.width, bitmap.height).toDouble())
            val w = (bitmap.width * scale).toInt().coerceAtLeast(1)
            val h = (bitmap.height * scale).toInt().coerceAtLeast(1)
            val resized = Bitmap.createScaledBitmap(bitmap, w, h, true)
            val out = ByteArrayOutputStream(); resized.compress(Bitmap.CompressFormat.JPEG, 82, out)
            if (resized !== bitmap) resized.recycle()
            bitmap.recycle()
            "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) { null }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION) {
            val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
            val action = pendingCameraAction
            pendingCameraAction = null
            if (!granted) {
                Toast.makeText(this, "需要相机权限才能使用拍照识别或扫码", Toast.LENGTH_SHORT).show()
                return
            }
            if (action == "barcode") {
                openBarcodeCamera()
            } else {
                showOcrSourceChooser()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_PICK) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); chooser = null
        } else if (requestCode == OCR_PICK) {
            val uri = data?.data ?: ocrCameraUri
            if (resultCode == RESULT_OK && uri != null) {
                recognizeFromUri(uri)
            } else {
                ocrCameraUri = null
            }
        } else if (requestCode == BARCODE_PICK) {
            val uri = barcodeCameraUri
            if (resultCode == RESULT_OK && uri != null) {
                recognizeBarcodeFromUri(uri)
            } else {
                barcodeCameraUri = null
            }
        }
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
