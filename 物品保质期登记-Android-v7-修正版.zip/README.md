# 物品保质期登记 Android v6 - 库存管理版

新增：
- 首页分类库存统计
- 当前筛选结果全选
- 批量删除
- 批量修改分类
- 批量修改存放位置
- CSV 导入
- CSV 导出
- 本地照片 + 本地缓存
- 保质期按月并按真实日历计算
- 日历直接修改保质期至
- 条码/二维码扫描
- 到期状态与提醒
- JSON 完整备份/恢复

注意：本地数据建议定期导出 JSON 备份。卸载 App 或清除 App 数据可能清除本地缓存。


## v6 新增
- 仓库 / 房间区域 / 货架层位三级位置字段
- 最低库存字段与低库存统计
- 仓储位置筛选
- 每日本地检查保质期与低库存状态
- Android 通知渠道：保质期与库存提醒
- 保留 v5 的批量操作、CSV/JSON 备份恢复、扫码、照片本地缓存、按月计算保质期等功能


## v7 修复
- 修复 MainActivity.kt 中 package/import 顺序导致的 Kotlin 语法错误。
- 统一 Java/Kotlin JVM target 为 17，解决 compileDebugKotlin 的 JVM target 不一致问题。
- GitHub Actions 自动解压仓库根目录 ZIP 后查找 settings.gradle.kts 并编译 APK。
