plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.example.expiryapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.expiryapp"
        minSdk = 24
        targetSdk = 35
        versionCode = 7
        versionName = "7.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
