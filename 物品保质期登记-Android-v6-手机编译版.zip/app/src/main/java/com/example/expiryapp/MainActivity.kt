import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

package com.example.expiryapp

import android.Manifest
import android.app.*
import android.os.Bundle
import android.webkit.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Toast
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
// v6_notification_channel
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val FILE_PICK = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "expiry_reminders_v6",
                "保质期与库存提醒",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        web = WebView(this)
        web.layoutParams = ViewGroup.LayoutParams(-1,-1)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webChromeClient = object: WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null); chooser=cb
                return try {
                    startActivityForResult(p?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type="image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                    }, FILE_PICK); true
                } catch(e: Exception) { chooser=null; false }
            }
        }
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(object {
            @JavascriptInterface fun scanBarcode() {
                runOnUiThread {
                    val scanner = GmsBarcodeScanning.getClient(this@MainActivity)
                    scanner.startScan()
                        .addOnSuccessListener { barcode ->
                            val raw = barcode.rawValue ?: ""
                            web.evaluateJavascript("setScannedBarcode(${org.json.JSONObject.quote(raw)})", null)
                        }
                        .addOnFailureListener { Toast.makeText(this@MainActivity, "扫码失败或已取消", Toast.LENGTH_SHORT).show() }
                }
            }
        }, "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==FILE_PICK) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data))
            chooser=null
        }
    }
    override fun onBackPressed() {
        if(web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
