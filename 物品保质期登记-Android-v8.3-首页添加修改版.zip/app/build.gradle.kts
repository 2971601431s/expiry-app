plugins {
    id("com.android.application")
    kotlin("android")
}
android { namespace="com.example.expiryapp"; compileSdk=35
    defaultConfig { applicationId="com.example.expiryapp"; minSdk=24; targetSdk=35; versionCode = 6; versionName = "6.0" }
    dependencies { implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    implementation("com.google.android.gms:play-services-mlkit-text-recognition-chinese:16.0.1")
    implementation("androidx.core:core-ktx:1.16.0") }
}
