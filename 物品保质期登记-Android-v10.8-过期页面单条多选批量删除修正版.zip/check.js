
const KEY='expiry_items_v1',CATKEY='expiry_categories_v1',BRANDKEY='expiry_brands_v1',FKEY='expiry_saved_filters_v1',DB_NAME='expiry_app_db_v1',DB_VERSION=1,STORE='items';
let recognizedPhoto='',items=[],cats=JSON.parse(localStorage.getItem(CATKEY)||'["食品","宠物食品","药品","日用品","其他"]'),brands=JSON.parse(localStorage.getItem(BRANDKEY)||'[]'),savedFilters=JSON.parse(localStorage.getItem(FKEY)||'[]');
let db=null,dbReady=null;
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=()=>{const d=r.result;if(!d.objectStoreNames.contains(STORE)){d.createObjectStore(STORE,{keyPath:'id'})}};r.onsuccess=()=>{db=r.result;resolve(db)};r.onerror=()=>reject(r.error||new Error('IndexedDB打开失败'))})}
function dbGetAll(){return new Promise((resolve,reject)=>{if(!db)return reject(new Error('数据库不可用'));const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error)})}
function dbPutAll(list){return new Promise((resolve,reject)=>{if(!db)return reject(new Error('数据库不可用'));const tx=db.transaction(STORE,'readwrite'),st=tx.objectStore(STORE);st.clear();list.forEach(x=>st.put(x));tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error('数据库写入失败'))})}
async function initStorage(){try{db=await openDB();let stored=await dbGetAll();if(stored.length===0){const legacy=JSON.parse(localStorage.getItem(KEY)||'[]');if(Array.isArray(legacy)&&legacy.length){items=legacy;await dbPutAll(items);localStorage.removeItem(KEY)}else items=[]}else items=stored;items.forEach(x=>{if(x.brand&&!brands.includes(x.brand))brands.push(x.brand)});localStorage.setItem(BRANDKEY,JSON.stringify(brands));return true}catch(e){console.error(e);db=null;items=JSON.parse(localStorage.getItem(KEY)||'[]');items.forEach(x=>{if(x.brand&&!brands.includes(x.brand))brands.push(x.brand)});return false}}
dbReady=initStorage().then(()=>renderAll());
async function persist(){try{localStorage.setItem(CATKEY,JSON.stringify(cats));localStorage.setItem(BRANDKEY,JSON.stringify(brands));localStorage.setItem(FKEY,JSON.stringify(savedFilters));await dbReady;if(db){await dbPutAll(items)}else{localStorage.setItem(KEY,JSON.stringify(items))}renderAll()}catch(e){console.error(e);try{localStorage.setItem(KEY,JSON.stringify(items))}catch(_){ }alert('本机存储失败，请先导出备份。\n如果照片很多，请减少单张照片大小后再试。')}}
let nav='home',tab='all',fc='',expiredCat='',sortDesc=false,selected=new Set();window.multiSelectMode=false;let undoItems=[],undoTimer=null,filterState={category:'',status:'',days:0,sort:'expiry'},selectedMode='auto';
function $(id){return document.getElementById(id)}
function esc(v){return String(v??'').replace(/[&<>\"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m]))}
function days(date){if(!date)return 99999;let t=new Date(date+'T00:00:00').getTime();return Math.ceil((t-Date.now())/86400000)}
function status(date){let d=days(date);return d<0?'expired':d<=30?'soon':'ok'}
function statusText(date){let d=days(date);return d<0?'已过期 '+Math.abs(d)+' 天':d===0?'今天到期':'还有 '+d+' 天'}
function renderCats(){
 let box=$('cats');
 if(!box)return;
 box.innerHTML='';
 let all=document.createElement('button');
 all.className='chip '+(!window.fc?'active':'');
 all.textContent='全部分类';
 all.onclick=()=>filterCat('');
 box.appendChild(all);
 cats.forEach(c=>{
  let b=document.createElement('button');
  b.className='chip '+(window.fc===c?'active':'');
  b.textContent=c;
  b.onclick=()=>filterCat(c);
  box.appendChild(b);
 });
}
function renderCategorySelect(){let el=$('category');if(!el)return;let cur=el.value;el.innerHTML='<option value="">请选择分类</option>'+cats.map(c=>'<option value="'+esc(c)+'">'+esc(c)+'</option>').join('');if(cur)el.value=cur}
function renderBrandSelect(){let el=$('brand');if(!el)return;let cur=el.value;el.innerHTML='<option value="">请选择品牌</option>'+brands.map(b=>'<option value="'+esc(b)+'">'+esc(b)+'</option>').join('');if(cur && !brands.includes(cur)){let opt=document.createElement('option');opt.value=cur;opt.textContent=cur;el.appendChild(opt)}if(cur)el.value=cur}
function card(x,opts={}){let st=status(x.expiry), cls=st==='expired'?'expired':st==='soon'?'soon':'ok';let photo=x.photo?'<img class="thumb" src="'+x.photo+'" alt="">':'<div class="thumb">暂无照片</div>';let meta=(x.brand?'品牌：'+esc(x.brand)+' · ':'')+(x.spec?esc(x.spec)+' · ':'')+'数量 '+(+x.qty||0);return '<div class="item"><div onclick="openForm('+JSON.stringify(x.id)+')" class="infoWrap">'+photo+'<div class="info"><div class="name">'+esc(x.name||'未命名')+'</div><div class="line">'+meta+'</div><div class="line">'+esc(x.category||'未分类')+'</div><span class="badge '+cls+'">'+statusText(x.expiry)+'</span></div></div><button class="editBtn" title="修改" data-id="'+esc(x.id)+'">✎</button></div>'}
function homeItems(){let arr=items.filter(x=>!x.handled);let q=$('search').value.trim().toLowerCase();if(q)arr=arr.filter(x=>[x.name,x.brand,x.spec,x.category,x.note,x.location].join(' ').toLowerCase().includes(q));if(window.fc)arr=arr.filter(x=>x.category===window.fc);if(tab==='soon')arr=arr.filter(x=>status(x.expiry)==='soon');if(window._activeSavedFilter)arr=applyFilterToItems(window._activeSavedFilter).filter(x=>arr.some(y=>y.id===x.id));return arr}
function renderHome(){let arr=homeItems();$('homeList').innerHTML=arr.length?arr.map(x=>card(x)).join(''):'<div style="padding:50px 20px;text-align:center;color:#9aa0ae">暂无物品<br><small>点击右下角 ＋ 添加第一件物品</small></div>';renderCats()}
function renderExpired(){
  const mode=window.expiredView||'expired';
  let arr=items.filter(x=>status(x.expiry)===mode&&!x.handled);
  if(expiredCat)arr=arr.filter(x=>String(x.category||'')===String(expiredCat));
  const visibleIds=new Set(arr.map(x=>String(x.id)));
  selected.forEach(id=>{if(!visibleIds.has(String(id)))selected.delete(id)});
  arr.sort((a,b)=>sortDesc?days(b.expiry)-days(a.expiry):days(a.expiry)-days(b.expiry));

  const catNames=[...new Set(cats.map(c=>String(c||'').trim()).filter(Boolean))];
  $('expCats').innerHTML='<button class="chip '+(!expiredCat?'active':'')+'" data-exp-cat="">全部分类</button>'+
    catNames.map(c=>'<button class="chip '+(String(expiredCat)===c?'active':'')+'" data-exp-cat="'+esc(c)+'">'+esc(c)+(String(expiredCat)===c?' ✓':'')+'</button>').join('');
  document.querySelectorAll('#expCats [data-exp-cat]').forEach(btn=>btn.addEventListener('click',()=>setExpiredCategory(btn.dataset.expCat||'')));

  $('sortDays').textContent=sortDesc?'↕ 按过期天数排序（由远到近）':'↕ 按过期天数排序（由近到远）';
  document.querySelectorAll('#expiredPage .sortbar button').forEach(b=>b.classList.remove('active'));
  if(mode==='expired')$('sortDays').classList.add('active');
  if(mode==='soon')document.querySelector('#expiredPage .sortbar button:nth-child(2)').classList.add('active');

  if(!arr.length){
    $('expiredList').innerHTML='<div style="padding:55px 20px;text-align:center;color:#9aa0ae">'+
      (mode==='soon'?'暂无即将过期商品':'暂无过期商品')+'</div>';
    updateBatchBar(arr);return;
  }
  $('expiredList').innerHTML=arr.map(x=>{
    const st=status(x.expiry), id=String(x.id), cat=esc(x.category||'未分类');
    const photo=x.photo?'<img class="thumb" src="'+x.photo+'" alt="">':'<div class="thumb">暂无照片</div>';
    const meta=(x.brand?'品牌：'+esc(x.brand)+' · ':'')+(x.spec?esc(x.spec)+' · ':'')+'数量 '+(+x.qty||0);
    const isSelected=selected.has(x.id)||selected.has(id);
    return '<div class="item expiredCard '+(window.multiSelectMode?'multiMode':'')+'" data-id="'+esc(id)+'">'+
      '<button type="button" class="selectBox '+(isSelected?'on':'')+'" aria-label="选择">'+(isSelected?'✓':'')+'</button>'+
      '<div class="info"><div style="display:flex;gap:10px;align-items:center">'+photo+
        '<div style="flex:1;min-width:0"><div class="name">'+esc(x.name||'未命名')+'</div>'+
        '<div class="line">'+meta+'</div>'+
        '<button type="button" class="line expCatBtn" title="按此分类筛选">分类：'+cat+(String(expiredCat)===String(x.category||'')?' ✓':'')+'</button>'+
        '<br><span class="badge '+st+'">'+statusText(x.expiry)+'</span></div></div></div>'+
      '<button type="button" class="editBtn" title="修改" aria-label="修改">✎</button>'+
    '</div>';
  }).join('');
  bindExpiredInteractions();
  updateBatchBar(arr);
}
function updateBatchBar(arr){
  const multiBtn=$('multiSelectBtn'),batchBtn=$('batchDeleteBtn');if(!multiBtn||!batchBtn)return;
  const count=selected.size;
  multiBtn.textContent=window.multiSelectMode?'☑ 完成多选':'☑ 多选';
  multiBtn.classList.toggle('primary',!!window.multiSelectMode);
  batchBtn.textContent='🗑 批量删除（'+count+'）';
  batchBtn.disabled=count===0;
}
function toggleMultiSelect(){window.multiSelectMode=!window.multiSelectMode;if(!window.multiSelectMode)selected.clear();renderExpired()}
function toggleItemSelection(id){
  if(!window.multiSelectMode)return;
  id=String(id);let found=[...selected].find(v=>String(v)===id);
  if(found!==undefined)selected.delete(found);else selected.add(id);
  renderExpired();
}
function openBatchDeleteConfirm(){
  if(!window.multiSelectMode||selected.size===0){return}
  $('batchDeleteText').textContent='将删除已选中的 '+selected.size+' 个商品，删除后可在5秒内点击“撤销”恢复。';
  $('batchDeleteBg').classList.add('open');
}
async function confirmBatchDelete(){
  const ids=new Set([...selected].map(String));if(!ids.size)return;
  const removed=items.filter(x=>ids.has(String(x.id)));
  if(!removed.length){selected.clear();window.multiSelectMode=false;closeSheet('batchDeleteBg');renderExpired();return}
  items=items.filter(x=>!ids.has(String(x.id)));
  selected.clear();window.multiSelectMode=false;
  closeSheet('batchDeleteBg');renderExpired();showUndo(removed,'已删除 '+removed.length+' 个商品');
  await persist();
}
function setExpiredCategory(c){expiredCat=String(c||'');selected.clear();renderExpired();const active=document.querySelector('#expCats .chip.active');if(active)active.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'})}
function bindExpiredInteractions(){
  const list=$('expiredList');if(!list)return;
  list.querySelectorAll('.expiredCard').forEach(card=>{
    const id=String(card.dataset.id||'');let timer=null,startX=0,startY=0,longPressed=false,suppressClickUntil=0;
    const clear=()=>{if(timer){clearTimeout(timer);timer=null}};
    const point=e=>{const t=e.touches&&e.touches[0]?e.touches[0]:e;return {x:Number(t.clientX)||0,y:Number(t.clientY)||0}};
    const start=e=>{
      if(e.target.closest('button'))return;
      const pt=point(e);startX=pt.x;startY=pt.y;longPressed=false;clear();
      timer=setTimeout(()=>{
        timer=null;longPressed=true;suppressClickUntil=Date.now()+1200;
        if(window.multiSelectMode){toggleItemSelection(id)}else{openSingleDeleteConfirm(id)}
        if(navigator.vibrate)navigator.vibrate(70);
      },2000);
    };
    const move=e=>{if(!timer)return;const pt=point(e);if(Math.hypot(pt.x-startX,pt.y-startY)>18)clear()};
    const end=()=>{clear();if(longPressed){setTimeout(()=>longPressed=false,50)}};
    card.addEventListener('touchstart',start,{passive:true});card.addEventListener('touchmove',move,{passive:true});card.addEventListener('touchend',end,{passive:true});card.addEventListener('touchcancel',clear,{passive:true});
    card.addEventListener('mousedown',start);card.addEventListener('mousemove',move);card.addEventListener('mouseup',end);card.addEventListener('mouseleave',clear);
    card.addEventListener('contextmenu',e=>e.preventDefault());
    card.addEventListener('click',e=>{
      if(Date.now()<suppressClickUntil)return;
      const catBtn=e.target.closest('.expCatBtn');if(catBtn){e.preventDefault();e.stopPropagation();setExpiredCategory(catBtn.textContent.replace(/✓/g,'').replace(/^分类：/,'').trim());return}
      const edit=e.target.closest('.editBtn');if(edit){e.preventDefault();e.stopPropagation();if(!window.multiSelectMode)openForm(id);return}
      const check=e.target.closest('.selectBox');if(check){e.preventDefault();e.stopPropagation();toggleItemSelection(id);return}
      if(window.multiSelectMode){toggleItemSelection(id);return}
      openForm(id);
    });
  });
}
let pendingDeleteId='';
function openSingleDeleteConfirm(id){
  const item=items.find(x=>String(x.id)===String(id));if(!item)return;
  pendingDeleteId=String(id);$('deleteText').textContent='将删除“'+(item.name||'未命名')+'”，删除后可在5秒内点击“撤销”恢复。';$('deleteBg').classList.add('open');
}
async function confirmSingleDelete(){
  const id=String(pendingDeleteId||'');if(!id){closeSheet('deleteBg');return}
  const item=items.find(x=>String(x.id)===id);if(!item){pendingDeleteId='';closeSheet('deleteBg');return}
  items=items.filter(x=>String(x.id)!==id);pendingDeleteId='';closeSheet('deleteBg');selected.delete(id);renderExpired();showUndo([item],'已删除 1 个商品');await persist();
}

function renderFilterCats(){let el=$('filterCats');if(!el)return;el.innerHTML='<button class="choice filterCategoryChoice '+(!filterState.category?'on':'')+'" data-cat="">全部</button>'+cats.map(c=>'<button class="choice filterCategoryChoice '+(filterState.category===c?'on':'')+'" data-cat="'+esc(c)+'">'+esc(c)+'</button>').join('');el.querySelectorAll('[data-cat]').forEach(btn=>btn.addEventListener('click',()=>pickCat(btn,btn.dataset.cat||'')))}
function savedFilterHtml(target){if(!savedFilters.length){target.innerHTML='<div class="mini">暂无保存的筛选条件</div>';return}target.innerHTML=savedFilters.map(f=>'<div class="savedRow"><div><b>'+esc(f.name)+'</b><div class="mini">'+(f.auto?'自动应用':'手动应用')+'</div></div><button onclick="applySaved('+JSON.stringify(f.id)+')">应用</button></div>').join('')}
function renderSavedFilters(){savedFilterHtml($('savedFilters'));savedFilterHtml($('mineSavedFilters'))}
function renderMine(){let active=items.filter(x=>!x.handled);$('statItems').textContent=active.length;$('statQty').textContent=active.reduce((s,x)=>s+(+x.qty||0),0);$('statWarn').textContent=active.filter(x=>['soon','expired'].includes(status(x.expiry))).length;renderSavedFilters()}
window.expiredView='expired';
function renderAll(){updateNav();renderHome();renderExpired();renderFilterCats();renderMine();}

function setTab(t){tab=t;$('tabAll').classList.toggle('active',t==='all');$('tabSoon').classList.toggle('active',t==='soon');renderHome()}function filterCat(c){window.fc=c;renderHome();renderCats()}
function updateNav(){['navHome','navExp','navFilter','navMine'].forEach(id=>$(id).classList.remove('active'));if(nav==='home')$('navHome').classList.add('active');if(nav==='expired')$('navExp').classList.add('active');if(nav==='filter')$('navFilter').classList.add('active');if(nav==='mine')$('navMine').classList.add('active');['homePage','expiredPage','filterPage','minePage'].forEach(id=>$(id).classList.remove('open'));if(nav==='home')$('homePage').classList.add('open');if(nav==='expired')$('expiredPage').classList.add('open');if(nav==='filter')$('filterPage').classList.add('open');if(nav==='mine')$('minePage').classList.add('open');$('homeFab').style.display=nav==='home'?'flex':'none'}
function setNav(n){nav=n;selected.clear();window.multiSelectMode=false;renderAll()}function openScanMenu(){$('scanBg').classList.add('open')}function closeSheet(id){$(id).classList.remove('open')}
function showUndo(changed,text){undoItems=changed;let u=$('undo');if(!u){u=document.createElement('div');u.id='undo';u.className='undo';u.innerHTML='<div class="uText"><b id="undoText"></b><div class="progress"><i id="undoProg"></i></div></div><button onclick="undoAction()">撤销 <span id="undoSec">5</span>s</button>';document.body.appendChild(u)}$('undoText').textContent=text;$('undoSec').textContent='5';$('undoProg').style.width='100%';u.classList.add('show');clearInterval(undoTimer);let sec=5;undoTimer=setInterval(()=>{sec--;$('undoSec').textContent=sec;$('undoProg').style.width=(sec/5*100)+'%';if(sec<=0){clearInterval(undoTimer);u.classList.remove('show');undoItems=[]}},1000)}
function undoAction(){clearInterval(undoTimer);if(undoItems.length){let restore=undoItems;let existing=new Set(items.map(x=>x.id));items=items.concat(restore.filter(x=>!existing.has(x.id)));items.sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));persist();renderAll()}$('undo').classList.remove('show');undoItems=[]}
function toggleSort(){sortDesc=!sortDesc;renderExpired()}
function setExpiredFilter(mode){window.expiredView=mode||'expired';selected.clear();window.multiSelectMode=false;renderExpired()}
function pickCat(btn,v){filterState.category=v;document.querySelectorAll('#filterCats .choice').forEach(x=>x.classList.remove('on'));btn.classList.add('on')}function pickStatus(btn,v){filterState.status=v;document.querySelectorAll('[data-status]').forEach(x=>x.classList.remove('on'));btn.classList.add('on')}function pickDateRange(btn,v){filterState.days=v;btn.parentElement.querySelectorAll('.choice').forEach(x=>x.classList.remove('on'));btn.classList.add('on')}function pickSort(btn,v){filterState.sort=v;btn.parentElement.querySelectorAll('.choice').forEach(x=>x.classList.remove('on'));btn.classList.add('on')}
function currentFilter(){return {...filterState,keyword:$('filterKeyword').value.trim()}}function applyFilterToItems(f){let arr=items.slice();if(f.category)arr=arr.filter(x=>x.category===f.category);if(f.status)arr=arr.filter(x=>status(x.expiry)===f.status);if(f.days)arr=arr.filter(x=>days(x.expiry)>=0&&days(x.expiry)<=f.days);if(f.keyword){let q=f.keyword.toLowerCase();arr=arr.filter(x=>[x.name,x.brand,x.spec,x.note,x.category].join(' ').toLowerCase().includes(q))}arr.sort((a,b)=>f.sort==='qty'?(+b.qty||0)-(+a.qty||0):f.sort==='created'?(b.createdAt||0)-(a.createdAt||0):days(a.expiry)-days(b.expiry));return arr}
function openSaveFilter(){selectedMode='auto';document.querySelectorAll('.modeCard').forEach(x=>x.classList.remove('selected'));$('saveFilterBg').classList.add('open')}function pickMode(btn){selectedMode=btn.dataset.mode;document.querySelectorAll('.modeCard').forEach(x=>x.classList.remove('selected'));btn.classList.add('selected')}function saveFilter(){let name=$('filterName').value.trim()||'我的筛选 '+(savedFilters.length+1),f={id:crypto.randomUUID(),name,mode:selectedMode,auto:selectedMode==='auto',conditions:currentFilter()};if(selectedMode==='once'){applyFilter(f.conditions);closeSheet('saveFilterBg');return}savedFilters.push(f);if(selectedMode==='auto')savedFilters.forEach(x=>{x.auto=x.id===f.id});$('filterName').value='';persist();closeSheet('saveFilterBg');if(selectedMode==='auto')applyFilter(f.conditions)}function applyFilter(f){filterState={...f};$('filterKeyword').value=f.keyword||'';window.fc=f.category||'';nav='home';
// v9.8 首页搜索与编辑修复
(function(){
  const searchBox=document.getElementById('search');
  if(searchBox){
    searchBox.addEventListener('input',function(){
      if(typeof renderHome==='function') renderHome();
      else if(typeof renderAll==='function') renderAll();
    });
  }
  document.addEventListener('click',function(e){
    const btn=e.target.closest('.editBtn');
    if(btn){
      e.preventDefault();
      e.stopPropagation();
      const id=btn.getAttribute('data-id');
      if(id && typeof openForm==='function') openForm(id);
    }
  });
})();

renderAll();let arr=applyFilterToItems(f);$('homeList').innerHTML=arr.length?arr.map(x=>card(x)).join(''):'<div class="empty"><div class="icon">📦</div><div>没有符合条件的物品</div></div>'}function applySaved(id){let f=savedFilters.find(x=>x.id===id);if(f)applyFilter(f.conditions)}
function openForm(id=''){recognizedPhoto='';$('form').reset();$('id').value=id;$('preview').style.display='none';$('preview').src='';renderCategorySelect();renderBrandSelect();if(id){let x=items.find(a=>a.id===id);if(!x){alert('找不到这件物品，请刷新后重试。');return;}$('formTitle').textContent='编辑物品';['name','brand','category','spec','production','expiry','location','barcode','note'].forEach(k=>$(k).value=x[k]||'');$('qty').value=x.qty??1;$('shelfMonths').value=x.shelfMonths||'';renderCategorySelect();renderBrandSelect();if(x.photo){$('preview').src=x.photo;$('preview').style.display='block'}}else{$('formTitle').textContent='新增物品';$('qty').value=1}$('formBg').classList.add('open')}
$('form').addEventListener('submit',e=>{e.preventDefault();let id=$('id').value||crypto.randomUUID(),old=items.find(x=>x.id===id),x={id,name:$('name').value.trim(),brand:$('brand').value.trim(),category:$('category').value,spec:$('spec').value.trim(),qty:+$('qty').value||0,production:$('production').value,expiry:$('expiry').value,shelfMonths:+$('shelfMonths').value||0,location:$('location').value.trim(),barcode:$('barcode').value.trim(),note:$('note').value.trim(),photo:old?.photo||recognizedPhoto||'',createdAt:old?.createdAt||Date.now(),handled:old?.handled||false,handledAt:old?.handledAt||null};let f=$('photo').files[0];if(f){let r=new FileReader();r.onload=()=>compressImage(r.result).then(img=>{x.photo=img;upsert(x)});r.readAsDataURL(f)}else upsert(x)});function upsert(x){let i=items.findIndex(a=>a.id===x.id);if(i<0)items.push(x);else items[i]=x;persist();closeSheet('formBg')}
// v9.6 修复：生产日期+保质期自动计算到期日期
function updateExpiryDate(){
  let p=$('production').value;
  let m=parseInt($('shelfMonths').value||0);
  if(!p || !m) return;
  let d=new Date(p);
  d.setMonth(d.getMonth()+m);
  $('expiry').value=d.toISOString().slice(0,10);
}
$('production').addEventListener('change',updateExpiryDate);
$('shelfMonths').addEventListener('input',updateExpiryDate);

function compressImage(data,max=1100,q=.8){return new Promise(res=>{let i=new Image();i.onload=()=>{let sc=Math.min(1,max/Math.max(i.naturalWidth,i.naturalHeight)),w=Math.round(i.naturalWidth*sc),h=Math.round(i.naturalHeight*sc),c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(i,0,0,w,h);res(c.toDataURL('image/jpeg',q))};i.src=data})}
function scanBarcode(){if(window.Android&&Android.scanBarcode)Android.scanBarcode();else alert('请在 Android App 中使用扫码功能。')}function recognizeProduct(){if(window.Android&&Android.recognizeProduct)Android.recognizeProduct();else alert('请在 Android App 中使用拍照识别功能。')}function setScannedBarcode(v){$('barcode').value=v||''}function setRecognizedProduct(json){try{let d=JSON.parse(json||'{}');recognizedPhoto=d.photo||'';if(d.brand&&!brands.includes(d.brand)){brands.push(d.brand);localStorage.setItem(BRANDKEY,JSON.stringify(brands));renderBrandSelect()}['name','brand','spec','production','expiry','shelfMonths','qty','barcode'].forEach(k=>{if(d[k])$(k).value=d[k]});if(d.photo){$('preview').src=d.photo;$('preview').style.display='block';$('photo').value=''}if(d.production&&d.shelfMonths&&!d.expiry)calcExpiry()}catch(e){alert('识别结果读取失败，请手动填写。')}}
function openCats(){renderCatList();$('catBg').classList.add('open')}function renderCatList(){$('catList').innerHTML=cats.map((c,i)=>'<div class="cat-row"><span>'+esc(c)+'</span><button onclick="delCat('+i+')">删除</button></div>').join('')}function addCat(){let c=$('newCat').value.trim();if(c&&!cats.includes(c)){cats.push(c);$('newCat').value='';persist();renderCatList()}}function delCat(i){let c=cats[i];if(cats.length<=1)return alert('至少保留一个分类');if(items.some(x=>x.category===c))return alert('该分类还有物品，请先修改分类');cats.splice(i,1);persist();renderCatList()}function openBrands(){renderBrandList();$('brandBg').classList.add('open')}function renderBrandList(){$('brandList').innerHTML=brands.length?brands.map((b,i)=>'<div class="cat-row"><span>'+esc(b)+'</span><button onclick="delBrand('+i+')">删除</button></div>').join(''):'<div class="mini">暂无品牌，请添加常用品牌。</div>'}function addBrand(){let b=$('newBrand').value.trim();if(b&&!brands.includes(b)){brands.push(b);$('newBrand').value='';persist();renderBrandList();renderBrandSelect()}}function delBrand(i){let b=brands[i];if(items.some(x=>x.brand===b))return alert('该品牌还有物品，请先修改品牌');brands.splice(i,1);persist();renderBrandList();renderBrandSelect()}
function exportData(){let blob=new Blob([JSON.stringify({version:5,exportedAt:new Date().toISOString(),categories:cats,brands,items,savedFilters},null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='物品保质期备份-'+new Date().toISOString().slice(0,10)+'.json';a.click()}$('importFile').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let d=JSON.parse(r.result);if(Array.isArray(d.categories))cats=d.categories;if(Array.isArray(d.brands))brands=d.brands;else if(Array.isArray(d.items))d.items.forEach(x=>{if(x.brand&&!brands.includes(x.brand))brands.push(x.brand)});if(Array.isArray(d.items))items=d.items;if(Array.isArray(d.savedFilters))savedFilters=d.savedFilters;persist();alert('备份导入完成')}catch(_){alert('备份文件格式不正确')}};r.readAsText(f);e.target.value=''})
function exportCSV(){let rows=[['名称','品牌','分类','规格','数量','生产日期','保质期至','保质期（月）','条码','存放位置','备注'],...items.map(x=>[x.name,x.brand||'',x.category,x.spec,x.qty,x.production,x.expiry,x.shelfMonths||'',x.barcode||'',x.location,x.note])],csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));a.download='物品登记-'+new Date().toISOString().slice(0,10)+'.csv';a.click()}$('csvFile').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{let lines=r.result.replace(/^\ufeff/,'').split(/\r?\n/).filter(Boolean);if(lines.length<2)return alert('CSV没有数据');let parse=s=>{let a=[],c='',q=false;for(let i=0;i<s.length;i++){let ch=s[i];if(ch==='"'&&s[i+1]==='"'){c+='"';i++;continue}if(ch==='"'){q=!q;continue}if(ch===','&&!q){a.push(c);c=''}else c+=ch}a.push(c);return a};lines.slice(1).map(parse).forEach(a=>{if(!a[0])return;let cat=a[2]||'其他',brand=a[1]||'';if(!cats.includes(cat))cats.push(cat);if(brand&&!brands.includes(brand))brands.push(brand);items.push({id:crypto.randomUUID(),name:a[0],brand:brand,category:cat,spec:a[3]||'',qty:+a[4]||0,production:a[5]||'',expiry:a[6]||'',shelfMonths:+a[7]||0,barcode:a[8]||'',location:a[9]||'',note:a[10]||'',photo:'',createdAt:Date.now(),handled:false})});persist();alert('CSV导入完成');e.target.value='' };r.readAsText(f)});

// v9.8 首页搜索与编辑修复
(function(){
  const searchBox=document.getElementById('search');
  if(searchBox){
    searchBox.addEventListener('input',function(){
      if(typeof renderHome==='function') renderHome();
      else if(typeof renderAll==='function') renderAll();
    });
  }
  document.addEventListener('click',function(e){
    const btn=e.target.closest('.editBtn');
    if(btn){
      e.preventDefault();
      e.stopPropagation();
      const id=btn.getAttribute('data-id');
      if(id && typeof openForm==='function') openForm(id);
    }
  });
})();


renderAll();
