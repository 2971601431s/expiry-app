plugins {
    id("com.android.application")
    kotlin("android")
}
android { namespace="com.example.expiryapp"; compileSdk=35
    defaultConfig { applicationId="com.example.expiryapp"; minSdk=24; targetSdk=35; versionCode = 10; versionName = "9.3" }
    dependencies { implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("androidx.core:core-ktx:1.16.0") }
}
